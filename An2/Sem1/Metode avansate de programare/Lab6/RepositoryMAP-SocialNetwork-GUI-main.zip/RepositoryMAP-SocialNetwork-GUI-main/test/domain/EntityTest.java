package com.example.social_network_gui_v2.domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EntityTest {

    @Test
    void getId() {
    }

    @Test
    void setId() {
    }
}