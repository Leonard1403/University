package com.example.social_network_gui_v2.domain;

import static org.junit.jupiter.api.Assertions.*;

class NetworkTest {

}